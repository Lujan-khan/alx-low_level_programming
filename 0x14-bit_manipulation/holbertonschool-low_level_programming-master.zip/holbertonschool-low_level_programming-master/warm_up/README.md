# Warm Up
A review of fundamentals for interview preparation.