#include "holberton.h"

/**
 * mul - multiplies two integers
 * @a: first integer
 * @b: second integer
 *
 * Return: addition of a and b
 */

int mul(int a, int b)
{
	return (a * b);
}
