#include "m.h"

/**
 * main - Entry point
 *
 * Return: Always
 */
int main(void)
{
	print_holberton();
	return (EXIT_SUCCESS);
}
/* Holberton */
