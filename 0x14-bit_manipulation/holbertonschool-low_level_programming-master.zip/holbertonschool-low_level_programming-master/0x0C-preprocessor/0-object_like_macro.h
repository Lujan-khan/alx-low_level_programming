#ifndef _0_OBJECT_LIKE_MACRO_H_
#define _0_OBJECT_LIKE_MACRO_H_

#define SIZE 1024

#endif /* _0_OBJECT_LIKE_MACRO_H_ */
