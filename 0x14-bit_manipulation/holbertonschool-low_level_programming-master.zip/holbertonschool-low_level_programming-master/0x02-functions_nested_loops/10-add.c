#include "holberton.h"

/**
 * add - adds two integers
 * @a: first integer
 * @b: second integer
 *
 * Return: addition of a and b
 */

int add(int a, int b)
{
	return (a + b);
}
